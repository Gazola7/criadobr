/*Essa funçao verificaria se a senha fornecida e igual a confirmaçao de senha*/

function confereSenha(){
    const senha = document.querySelector('input[name=senha]');
    const confirma = document.querySelector('input[name=senha_confirma]');

    if(confirma.value === senha.value){
        confirma.setCustomValidity('');
    }
    else{
        confirma.setCustomValidity('Senhas não conferem');
    }
}
