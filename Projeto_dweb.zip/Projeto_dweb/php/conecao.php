<?php
        
    $dbname = "eduarda_tiago";
    $usuario = "root";
    $senhabd = "Hinacio240506";
    $hostname = "localhost";
        
    $pdo = new PDO ("mysql:host=localhost;dbname=$dbname","$usuario","$senhabd");

?>