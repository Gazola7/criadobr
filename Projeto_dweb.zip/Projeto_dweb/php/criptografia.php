<?php
//senha sendo criptografada com md5 para o banco de dados
            $senha = md5(md5($_POST['senha']));
            ?>