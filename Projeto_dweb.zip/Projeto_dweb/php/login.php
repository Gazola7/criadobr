<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8"> 
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/login.css">
</head>
<div class="content"> 
    <header>
        <img src="imagens/logo.jpg" alt="logo da loja maria mariah" height="150" width="150"> 
        <h1>Maria Mariah</h1>
    </header>
<body>
    <?php
      include("/xampp/htdocs/Projeto_dweb/php/crudlogin.php");
    ?>
    <main>
        <form method="POST">
            <div class="input-field">
                <input id="email" type="email" placeholder="Email" required>
                <label for="email">
                    <img src="imagens/avatar.svg" alt="Email" >
                </label>
            </div>
            <div class="input-field">
                <input type="password" placeholder="Senha" id="password" required>
                <label for ="password">
                    <img src="imagens/lock.svg" alt="Senha" >
                </label>
            </div>
           
            <div class="checkbox">
                <input type="checkbox" checked id="remid-pass" required>
                <label for ="remid-pass">Lembrar senha</label>
            </div>
            <button>
                Login
            </button>
        </form>
    </main>
    <footer>
    <span><a href="#">Esqueci minha senha</a></span>
    <a href="#">Criar nova conta</a>
    </footer>
    </div> 
</body>
</html>