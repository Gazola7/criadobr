<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="./assets/favicon.png" type="image/x-icon">
    <title>Maria Mariah</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="styles/style.css">
  </head>

  
<body>
    
    <nav class="navbar navbar-expand-md bg-135159 navbar-dark">

        <div class="container-fluid">
           <!--fixa a imagem no local--> 
          <a class="navbar-brand" href="#"><h1 class="n-0"><img class="d-block" src="imagens/logo.jpg" alt="Logo da loja"  height="45" width="45"></h1></a>

          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-xxl-0"> <!---m significa margem e o b significa botton / margem inferior , o primeiro mb não especifica qual tela é--->
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Home</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="#">Lojas</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="arquivo.html">Sugestões</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="enviaremail.html">Enviar email</a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="imagens/Digital_Eduarda.pdf">Minhas redes</a>
              </li>
            </ul>

            <form class="d-flex" role="search">
              <input class="form-control me-2 rounded-5" type="search" placeholder="Digite o produto" aria-label="Pesquisar">
              <button class="btn btn-outline-light rounded-5" type="submit">Buscar</button>
            </form>

          </div>

        </div>

      </nav>
        <!--Carrossel para que as imagens fiquem passando-->
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="img-fluid d-md-none" src="imagens/images carrossel.jpg" alt="Modelo feminina vestindo blusa rosa">
            <img class="img-fluid d-none d-md-block d-xl-none" src="imagens/images carrossel.jpg" alt="Modelo feminina vestindo blusa rosa"> <!--d -- none some quando estiver no mobile-->
            <img class="img-fluid d-md-none d-xl-block" src="imagens/images carrossel.jpg" alt="Modelo feminina vestindo blusa rosa">
            <div class="carousel-caption d-none d-md-block">
              <h5>First slide label</h5>
              <p>Some representative placeholder content for the first slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img  class="img-fluid d-md-none" src="/assets/Mobile/banner2-mobile.png" alt="Modelo feminina vestindo blusa rosa">
            <img class="img-fluid d-none d-md-block d-xl-none" src="./assets/Tablet/banner2-tablet.png" alt="Modelo feminina vestindo blusa rosa">
            <img class="img-fluid d-md-none d-xl-block" src="/assets/Desktop/banner2-desktop.png" alt="Modelo feminina vestindo blusa rosa">
            <div class="carousel-caption d-none">
              <h5>Second slide label</h5>
              <p>Some representative placeholder content for the second slide.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img class="img-fluid d-md-none" src="/assets/Mobile/banner3-mobile.png" alt="">
            <img class="img-fluid d-none d-md-block d-xl-none" src="./assets/Tablet/banner3-tablet.png" alt="Modelo feminina vestindo blusa rosa">
            <img class="img-fluid d-md-none d-xl-block" src="/assets/Desktop/banner3-desktop.png" alt="Modelo feminina vestindo blusa rosa">
              </div>

            <div class="carousel-caption d-none d-md-block">
              <h5>Third slide label</h5>
              <p>Some representative placeholder content for the third slide.</p>
            </div>
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>

      <h2 class="text-center my-3">Busque por Categoria</h2>

    
      <div class="container row mx-auto g-4"> <!--m é margem e x significa tanto para direita quanto para esquerda e p é padding espaçamento entre elementos (py esp. interno de baixo pra cima, pode ser pb bt mb )-->

        <div class="card-body">
            <h4 class="card-title"><p class = "text-center"> Produtos</p></h4>
            <p class="card-text">
            </div>
        
            
            <div class="col-6 col-md-4  col-xxl-2">
              <div class="card">
                  <img src="imagens/imagem16.jpg" class="card-img-top" alt="gato">
                  <div class="card-header">
                    <p class="text-center">Jaqueta</p>
                    <a href="#" class="btn btn-primary">Compre já</a>
                  </div>
                  </div>
                  </div>

            <div class="col-6 col-md-4  col-xxl-2">
            <div class="card">
                <img src="imagens/imagem11.jpg" class="card-img-top" alt="gato">
                <div class="card-header">
                  <p class="text-center">Cropeds</p>
                  <a href="#" class="btn btn-primary">Compre já</a>
                </div>
                </div>
                </div>

                
                    <div class="col-6 col-md-4  col-xxl-2">
                    <div class="card">
                        <img src="imagens/imagem7.jpg" class="card-img-top" alt="gato">
                        <div class="card-header">
                          <p class="text-center">Calças</p>
                          <a href="#" class="btn btn-primary"  >Compre já</a>
                        </div>
                        </div>
                        </div>

                        
      </div>
        <!--Organizando os produtos para o cliente poder comprar-->
      <h2 class="conteiner text-center my-3 my-xl-5">Produtos que estão bombando</h2>

      <div class="container row mx-auto align-items-center g-4">

        <div class="card col-6 col-md-4  col-xxl-2 " style="width: 18rem;">
          <img src="imagens/imagem8.jpg" class="card-img-top" alt="gato preto">
          <div class="card-header">
            <p class="text-center">Blusa manga bordada</p>
            <a href="#" class="btn btn-primary">Compre já</a>
            <p>R$ 60.00</p>
          </div>
          </div>
  
          <div class="card" style="width: 18rem;">
            <img src="imagens/imagem13.jpg" class="card-img-top" alt="gato preto">
            <div class="card-header">
              <p class="text-center">Calça afaiataria</p>
              <a href="#" class="btn btn-primary">Compra já</a>
              <p>R$ 150.00</p>
            </div>
            </div>
  
            <div class="card" style="width: 18rem;">
              <img src="imagens/imagem14.jpg" class="card-img-top" alt="gato preto">
              <div class="card-header">
                <p class="text-center">Calça pantalona</p>
                <a href="#" class="btn btn-primary">Compre já</a>
                <p>R$ 175.00</p>
              </div>
              </div>
  
              <div class="card" style="width: 18rem;">
                <img src="imagens/imagem12.jpg" class="card-img-top" alt="gato preto">
                <div class="card-header">
                  <p class="text-center">Blusa de lã</p>
                  <a href="#" class="btn btn-primary">Compre já</a>
                  <p>R$ 65.00</p>
                </div>
                </div>
  
                <div class="card" style="width: 18rem;">
                  <img src="imagens/imagem15.jpg" class="card-img-top" alt="gato preto">
                  <div class="card-header">
                    <p class="text-center">Blusa manga rendada</p>
                    <a href="#" class="btn btn-primary">Compre já</a>
                    <p>R$ 65.00</p>
                  </div>
                  </div>
  
                  <div class="card" style="width: 18rem;">
                    <img src="imagens/imagem16.jpg" class="card-img-top" alt="gato preto">
                    <div class="card-header">
                      <p class="text-center">Jaqueta de couro</p>
                      <a href="#" class="btn btn-primary">Compre já</a>
                      <p>R$ 250.00</p>
                    </div>
                    </div>
      </div>
  

      <section class="pb-4"> <!--padding-->

        <h2 class="text-center">Conheça as nossas facilidades</h2>

       <div class="d-flex flex-column align-items-center gap-3"> <!--centralizando a parte do codigo com as imagens-->

        <div class="divs-facilidades d-flex">
          <div><i class="bi bi-x-diamond fs-1"></i></div> <!--fs é o tamanho da fonte-->
          
          <div>
            <div class=" ms-3 mb-1">PAGUE PELO PIX</div>
            <div class="texto-menor ms-3">Ganhe 5% OFF em pagamentos via direct.</div>
          </div>

        </div>

        <div class="divs-facilidades d-flex">
          <div><i class="bi bi-arrow-repeat fs-1"></i></div>

          <div>
          <div class=" ms-3 mb-1">TROCA GRÁTIS</div>
          <div class="texto-menor ms-3">Fique livre para trocar em até 30 dias.</div>
          </div>

        </div>

        <div class="divs-facilidades d-flex"> 
          <div><i class="bi bi-geo-alt fs-1"></i></div>

          <div>
          <div class=" ms-3 mb-1">LOJA FÍSICA</div>
          <div class="texto-menor ms-3">Venha visitar nossa loja física em Cataguases, Rua Valentim Pereira da Rocha, 80.</div> <!--ms-3 é o espaçamento-->
          </div>

        </div>

       </div>

        </section>

        <form class="border border-secondary m-3 my-xl-5 p-3 text-center ">
          <h5>Quer receber nossas novidades, promoções exclusivas e 10% OFF na primeira compra? Cadastre-se!</h5>
          <div class="input-group my-3">
            <input type="email" class="form-control border-secundary rounded-0" placeholder="Digite seu e-mail" aria-label="Digite seu e-mail" aria-describedby="button-addon2"></input>
            <button type="button" idn="button-addon2"> Enviar </button>
          </div>        
        </form>

        <footer class="text-center">

          <p class="py-3"> 2023 <i class="bi bi-c-circle"></i> Desenvolvido por Sophia Lopes e Hinacio Gazola, alunos do CEFET-Leopoldina | Projeto sem fins comerciais</p>
    
        </footer>
      

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html>