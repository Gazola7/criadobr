<?php

    include("/xampp/htdocs/Projeto_dweb/php/conecao.php");
    include("/xampp/htdocs/Projeto_dweb/php/phpOO.php");
    
    if(isset($_POST['email'])){

        $id_cliente = null;
        $cpf = null;
        $nome = null;
        $email = $_POST['email'];
        $telefone = null;
        $endereço = null;
        $sexo = null;
        $data_nascimento = null;
        $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

        
        $pdo = new PDO ("mysql:host=localhost;dbname=$dbname","$usuario","$senhabd");
    
        $sql = $pdo -> prepare("INSERT INTO perfil (id,cpf,nome,email,telefone,endereço,sexo,data_nascimento,senha) VALUES (null,null,null, ?, null,null,null,null,?)");
    
        $sql -> execute(array($email, $nome_de_usuario, $senha));
        echo "Novo registro criado com sucesso"; 
    
        header('Location: http://localhost/Projeto_dweb/php/novo.php'); 

     } 

    /*  */
  
?>