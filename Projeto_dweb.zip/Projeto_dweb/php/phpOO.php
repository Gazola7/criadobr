<?php

class BancoDeDados {

    private $conecao;

}

class Usuario {

        private $id_cliente;
        private $cpf;
        private $nome;
        private $email;
        private $telefone;
        private $endereço;
        private $sexo;
        private $data_nascimento;
        private $senha;

    public function __construct($id_cliente,$cpf,$nome,$email,$telefone,$endereço,$sexo,$data_nascimento,$senha) {

        $this -> id_cliente = $id_cliente;
        $this -> cpf = $cpf;
        $this -> nome = $nome;
        $this -> email = $email;
        $this -> telefone = $telefone;
        $this -> endereço = $endereço;
        $this -> sexo = $sexo;
        $this -> data_nascimento = $data_nascimento;
        /*$this -> senha = password_hash($senha, PASSWORD_DEFAULT);*/

    }

    public function inserir($db) {

        $sql = "INSERT INTO cliente (id,cpf,nome,email,telefone,endereço,sexo,data_nascimento,senha) VALUES ('$codigo', '{$this->id_cliente}', '{$this->cpf}', '{$this->nome}', '{$this->email}', '{$this->telefone}', '{$this->endereço}', '{$this->sexo}', '{$this->data_nascimento}', '{$this->senha}')";

        $db->exec($sql);

    }

}

?>